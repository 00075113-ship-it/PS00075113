<!DOCTYPE html>
<html lang="en">
<head>
		<link href="../css/malcolmhall.css" rel="stylesheet" type="text/css" />
		<title>Post Details</title>
		<meta charset="utf-8">
</head>
<body>
  	<div class="header">
		<div class="header-left">
			<nav>
				<ul>
					<li><a href="../index.php">Home</a></li>
					<li><a href="../html/ContactUs.html">Contact Us</a></li>
					<li><a href="Gallery.php">Gallery</a></li>
				</ul>
			</nav>
		</div>
		<div class="header-right">
			<nav>
				<ul>
					<li><a href="../html/SignIn.html"> Sign In</a></li>
					<li><a href="../html/Register.html"> Register</a></li>
				</ul>
			</nav>
		</div>
	</div>
  <div class="container">
    <div class="nav">
      <ul>
      </ul>
    </div>     
    <body>
        <div class="registered-content"
        <?php
        $server = 'localhost';
        $user = 'root';
        $pass = '';
        $dbase = 'photoshare';
         $conn = mysqli_connect($server, $user, $pass, $dbase);
         if (!$conn){
            die('Could not connect to the database because: '. mysqli_connect_error());
         }

        $memid = $_POST["memberid"];
        $fname = $_POST["firstname"];
        $lname = $_POST["lastname"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $interest = $_POST["photointerest"];
        $avatar_dir = "../img/";
        $avatar_file = $avatar_dir . basename($_FILES["avatar"]["name"]);
        $uploadOk = 1;
        if(isset($_POST["submit"])) {
        $avatarcheck = getimagesize($_FILES["avatar"]["tmp_name"]);
        if($avatarcheck !== false) {
        echo "File is an image - " . $avatarcheck["mime"] . ".";
        $uploadOk = 1;
        } else {
        echo "File is not an image.";
        $uploadOk = 0;
        }
        }
        if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $avatar_file)) {
                echo "Avatar saved successfully.<br>";
        } else {
                echo "Avatar upload failed.<br>";
        }
        }

        echo "Welcome $fname. Thank you for joining our photography club. <br>";

        $qry = "INSERT INTO members (member_id, first_name, last_name, email, phone, avatar, photography_interest) values ('$memid', '$fname', '$lname', '$email' , '$phone', '$avatar_file', '$interest');";
        $result = mysqli_query($conn, $qry);

        if ($result) echo 'Record sucessfully inserted. <br><br>';
        else echo 'Error occured: ' . mysqli_error($conn) . '<br><br>';
            echo "<h2><a href=\"../index\">Return to the homepage</a></h2><p>Full Name: $fname $lname <br>Email Address: $email <br> Avatar: <br></p>";
            echo "<p><img src=\"../img/$avatar_file\" alt=\"Your Avatar\" width=\"400\" height=\"400\"></p>";

        mysqli_close($conn);
        ?>
    </div>
    <div class="footer">
		<p> Copyright © 2026 Malcolm Web Services. All rights reserved. </p>

    </div>
  </div>
  
</body>
</html>