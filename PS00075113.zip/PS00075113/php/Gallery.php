<!doctype html>
<html lang="en-US">
<head>
		<link href="../css/malcolmhall.css" rel="stylesheet" type="text/css" />
		<title>Gallery</title>
		<meta charset="utf-8">
</head>
<body>
	<div class="header">
		<div class="header-left">
			<nav>
				<ul>
					<li><a href="../index.html">Home</a></li>
					<li><a href="../html/ContactUs.html">Contact Us</a></li>
					<li><a href="Gallery.php">Gallery</a></li>
				</ul>
			</nav>
		</div>
		<div class="header-right">
			<nav>
				<ul>
					<li><a href="../html/SignIn.html"> Sign In</a></li>
					<li><a href="../html/Register.html"> Register</a></li>
				</ul>
			</nav>
		</div>
	</div>
	<br>
	<h1>Gallery</h1>	
	<div class="gallery-content">
		<?php
      $server = 'localhost';
      $user = 'root';
      $pass = '';
      $database = 'photoshare';

      $conn = mysqli_connect($server, $user, $pass, $database);
      if (!$conn){
        die('Database Connection failed ' . mysqli_connect_error());
        }
		$post_image = '';
        $query = "select * from posts order by post_date desc";
                $result = null;
          try { 
            $result = mysqli_query($conn, $query);  
            } catch (Exception $e){ 
            echo '<br><br>Error occurred: ' . mysqli_error($conn) . '<br><br>'; 
            echo "Please <a href=\"index.html\">return to form</a> to resubmit";  
          } 



          if ($result) { 
          if (mysqli_num_rows($result) > 0) {                      
			while ($row = mysqli_fetch_assoc($result)) {
			echo "<br> <img src=\"$row[post_image]\" alt=\"image\" width=\"450\" height=\"250\"> <br> <h2><a href=\"../php/post-details.php?post_id=$row[post_id]\">$row[post_date] - $row[post_title]</a> </h2>";
	  		}  
          }        
          }        
          else {               
            echo "<br>Query executed.  No matching records found.";       
          }
?>
		</div>
	<br>
	<div class="footer">
		<p> Copyright © 2026 Malcolm Web Services. All rights reserved. </p>
	</div>
</body>
</html>