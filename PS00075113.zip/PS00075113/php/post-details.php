<!DOCTYPE html>
<html lang="en">
<head>
		<link href="../css/malcolmhall.css" rel="stylesheet" type="text/css" />
		<title>Post Details</title>
		<meta charset="utf-8">
</head>
<body>
  	<div class="header">
		<div class="header-left">
			<nav>
				<ul>
					<li><a href="../index.php">Home</a></li>
					<li><a href="../html/ContactUs.html">Contact Us</a></li>
					<li><a href="Gallery.php">Gallery</a></li>
				</ul>
			</nav>
		</div>
		<div class="header-right">
			<nav>
				<ul>
					<li><a href="../html/SignIn.html"> Sign In</a></li>
					<li><a href="../html/Register.html"> Register</a></li>
				</ul>
			</nav>
		</div>
	</div>
  <div class="container">
    <div class="nav">
      <ul>
      </ul>
    </div>
    <div class="post-details">
            <?php
    echo "<br><br><h3>Post Details:</h3>";
      $server = 'localhost';
      $user = 'root';
      $pass = '';
      $database = 'photoshare';

      $conn = mysqli_connect($server, $user, $pass, $database);
      if (!$conn){
        die('Database Connection failed ' . mysqli_connect_error());
        }
        
        $postid = "";

        
        if(isset($_GET['post_id'])) $postid = $_GET['post_id'];

        $query = "select * from posts where post_id ='$postid';";
                $result = null;
          try { 
            $result = mysqli_query($conn, $query);  
            } catch (Exception $e){ 
            echo '<br><br>Error occurred: ' . mysqli_error($conn) . '<br><br>'; 
            echo "Please <a href=\"index.html\">return to form</a> to resubmit";  
          } 



          if ($result) { 
          if (mysqli_num_rows($result) > 0) {                      
          while ($row = mysqli_fetch_assoc($result)){ 
            echo "<img src=\"$row[post_image]\"> <p>Post Title: $row[post_title]<br>Post Description: $row[post_description] <br>Post Location: $row[post_location]<br>Post Date: $row[post_date]</p>";   
          
            }        
          }        
          else {               
            echo "<br>Query executed.  No matching records found.";       
          } 
          }
      mysqli_close($conn);
      ?>
    </div>
    <div class="footer">
		<p> Copyright © 2026 Malcolm Web Services. All rights reserved. </p>

    </div>
  </div>
  
</body>
</html>