-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 13, 2026 at 09:02 PM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photoshare`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photography_interest` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=694204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `first_name`, `last_name`, `email`, `phone`, `avatar`, `photography_interest`) VALUES
(100, 'Malcolm', 'Hall', '00075113@my.costaatt.edu.tt', '3349471', '../img/images.jpg', 'Landscape'),
(7, 'Sarita', 'Arjoon', 'sarjoon@live.com', '608-7633', '../img/images (1).jpg', 'Travel'),
(6, 'Samantha', 'Sam', 'ssam@live.com', '304-4421', '../img/3109096ed3be7cedba30ce27c0e5c525.jpg', 'Wildlife'),
(5, 'John', 'Jack', 'jjack@live.com', '219-2221', '../img/thumb-1920-375449.jpeg', 'Real Estate'),
(4, 'Rakeha', 'Sahadeo', 'rsahadeo@live.com', '765-3252', '../img/anime-pfp-jjk-boy-3-4.jpg', 'Fashion'),
(3, 'Candace', 'Ramsaran', 'cramsaran@live.com', '329-3234', '../img/images (2).jpg', 'Portrait'),
(2, 'Sarah', 'Hall', 'shall@live.com', '299-2928', '../img/ab6761610000517432d9a4454bd5d6f10a835b93.jpg', 'Wedding/Event'),
(1, 'Malcolm', 'Hall', 'mhall@live.com', '334-9471', '../img/41b7116ed040864dd32c7b09e4ba536e.jpg', 'Travel');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `post_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_image` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_description` text COLLATE utf8mb4_unicode_ci,
  `post_location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`),
  UNIQUE KEY `post_image` (`post_image`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `member_id`, `post_title`, `post_image`, `post_description`, `post_location`, `post_date`) VALUES
(1, 1, '\"My First Wedding Gig\"', 'https://media.architecturaldigest.com/photos/65e7bfaf9257bd9a533e18eb/16:9/w_1600,c_limit/0350E&J.jpg', 'The wedding cermony between Brynne and Austin; my good friends', 'Dallas, Texas', '2015-04-24 01:24:09'),
(2, 2, '\"Day At The Bird Sanctuary\"', 'https://www.destinationtnt.com/wp-content/uploads/caroni-swamp-and-bird-sanctuary-IMG_0137-800x534.jpg', 'Shot of Scarlet Ibises, the National Bird of Trinidad and Tobago mid-flight.', 'Caroni, Trinidad & Tobago', '2021-04-22 03:45:04'),
(3, 2, '\"Caribbean\'s Hidden Gem\"', 'https://lizzydavis.com/wp-content/uploads/2022/01/DSC_8012-1024x612.jpg ', 'This is the Bottom Bay beach. A beach hidden away in the south-eastern part of Barbados.', 'Saint Philip, Barbados', '2024-04-12 02:07:31'),
(4, 3, '\"A Resting Leopard\"', 'https://s3.eu-west-3.amazonaws.com/cdn.bigcatsindia.com/wp-content/uploads/2019/05/08135426/national-parks-for-wildlife-photography.jpg', 'An Indian Leopard laying down in a tree in the Jim Corbett National Park', 'Uttarakhand, India', '2026-04-06 16:03:50'),
(5, 5, 'Sunrise in the Misty Valley', 'https://assets.tommackie.com/wp-content/uploads/2021/05/25145056/180540-1-1-1024x684.jpg', 'Yosemite Valley, covered in mist', 'California, USA', '2020-08-01 19:25:46'),
(6, 4, '\"The Canyon at Dusk\"', 'https://assets.tommackie.com/wp-content/uploads/2021/05/25133435/970142-2-1024x688.jpg', 'The Bryce Canyon National Park in the late evening hours', 'Utah, USA', '2019-04-02 19:27:46'),
(7, 7, '\"The Ghastly Cold Grand Canyon\"', 'https://assets.tommackie.com/wp-content/uploads/2021/05/25133359/120111-1-1024x682.jpg', 'Grand Canyon National Park', 'The Grand Canyon, covered in snow at dusk', '2019-11-29 19:32:59');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
