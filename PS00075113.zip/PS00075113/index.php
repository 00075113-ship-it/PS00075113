<!doctype html>
<html lang="en-US">
	<head>
			<link href="css/malcolmhall.css" rel="stylesheet" type="text/css">
			<title>Home</title>
			<meta charset="utf-8">
	</head>
	<body>
		<div class="header">
			<div class="header-left">
				<nav>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="html/ContactUs.html">Contact Us</a></li>
						<li><a href="php/Gallery.php">Gallery</a></li>
					</ul>
				</nav>
			</div>
			<div class="header-right">
				<nav>
					<ul>
						<li><a href="html/SignIn.html"> Sign In</a></li>
						<li><a href="html/Register.html"> Register</a></li>
					</ul>
				</nav>
			</div>
		</div>

		<br><br><br>

		<div class="main-content">
			<h1>See it? Snap it!</h1>
			<br>
			<h1>WHO ARE WE?</h1>
			<br>
			<?php


$server = 'localhost';
			$user = 'root';
			$pass = '';
			$database = 'photoshare';

			$conn = mysqli_connect($server, $user, $pass, $database);
			if (!$conn){
			die('Database Connection failed ' . mysqli_connect_error());
			}
			$query = "select * from posts order by post_date desc limit 3";
			$result = null;
          try { 
            $result = mysqli_query($conn, $query);  
            } catch (Exception $e){ 
            echo '<br><br>Error occurred: ' . mysqli_error($conn) . '<br><br>'; 
            echo "Please <a href=\"index.html\">return to form</a> to resubmit";  
          } 
			if ($result) { 
         	 if (mysqli_num_rows($result) > 0) {                      
				$row1 = mysqli_fetch_assoc($result);
				$row2 = mysqli_fetch_assoc($result);
				$row3 = mysqli_fetch_assoc($result);
 					echo "<br> <img src=\"$row1[post_image]\"  alt=\"image\" width=\"450\" height=\"250\" style=\"float:right\"><h2><strong>Welcome to PhotoShare, a community designed by and for photographers. We are a committed group of amateur photographers who think that every outstanding image should be noticed. Whether you captured a gorgeous sunset, a candid street scene, or a perfectly timed wildlife photo, this is the place to share it with the world.</strong></h2>
					<br><br><br><br><br><br><hr>";		
					mysqli_fetch_assoc($result);
 					echo "<br> <img src=\"$row2[post_image]\"  alt=\"image\" width=\"450\" height=\"250\" style=\"float:left\"><br><br><br><h2><strong><em>As a PhotoShare member, you may contribute your own photographs and events, view the work of other photographers, and write comments to inspire and interact with the community. We celebrate photography at all skill levels, from new DSLR owners to seasoned amateurs. Every upload tells a story, and we're here to help you tell your own.</em></strong></h2><br><br><br><br><br><br><hr>";
					mysqli_fetch_assoc($result);
 					echo "<br> <img src=\"$row3[post_image]\"  alt=\"image\" width=\"450\" height=\"250\" style=\"float:right\"><br><br><br><h2><strong><em>Anyone who likes photography may join for free. Register today to begin sharing your work, connecting with our expanding community, and finding great photographs from other photographers like you. Your next favourite photograph is waiting to be discovered.</em></strong><br><br><br><br><br></h2><hr>";
					}
			 }

			?>
<br><br>
			<p><a href="html/Register.html">Join us, won't you?</a></p>
	
		</div>
		<br>	
		<div class="footer">
			<p> Copyright © 2026 Malcolm Web Services. All rights reserved. </p>
		</div>
	</body>
</html>